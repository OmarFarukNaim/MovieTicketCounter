from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseRedirect,HttpResponseBadRequest
from .models import Product, CartItem, Order,OrderItem
from .forms import UserRegistrationForm, UserLoginForm
from sslcommerz_lib import SSLCOMMERZ 
from django.urls import reverse


def register(request):
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration successful! You can now log in.")
            return redirect("login")
    else:
        form = UserRegistrationForm()
    return render(request, "register.html", {"form": form})


def user_login(request):
    if request.method == "POST":
        form = UserLoginForm(request.POST)
        
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.success(request, f"Welcome, {user.username}!")
                return redirect("home")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            
               
            messages.error(request, "Invalid form submission. Please check the fields.")
    else:
        form = UserLoginForm()
    
    return render(request, "login.html", {"form": form})
@login_required(login_url='login')
def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("login")


def home(request):
    products = Product.objects.all()
    return render(request, "home.html", {"products": products})

@login_required(login_url='login')
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item, created = CartItem.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    messages.success(request, f"{product.name} added to cart!")
    return redirect("cart")


@login_required(login_url='login')
def cart(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total_amount = sum(item.total_price() for item in cart_items)

     
    if request.method == "POST":
        product_id = request.POST.get('product_id')
        action = request.POST.get('action')

        cart_item = CartItem.objects.get(user=request.user, product_id=product_id)

         
        if action == 'increase':
            cart_item.quantity += 1
        elif action == 'decrease' and cart_item.quantity > 1:
            cart_item.quantity -= 1
        elif action == 'remove':
            cart_item.delete()
            return redirect('home')

        cart_item.save()
        return redirect('cart')   

    return render(request, 'cart.html', {'cart_items': cart_items, 'total_amount': total_amount})
 

@login_required(login_url='login')
def checkout(request):
    cart_items = CartItem.objects.filter(user=request.user)
    if not cart_items:
        messages.info(request, "Your cart is empty.")
        return redirect('cart')

    total_amount = sum(item.total_price() for item in cart_items)
    
    if request.method == "POST":
        delivery_address = request.POST.get('address')
        order = Order.objects.create(
            user=request.user,
            delivery_address=delivery_address,
            total_amount=total_amount
        )

        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity
            )

        cart_items.delete()
        messages.success(request, "Your order has been placed successfully!")
        
        # Store total_amount in the session
        request.session['total_amount'] = int(total_amount)
        return redirect('payment')
    
    return render(request, 'checkout.html', {
        'cart_items': cart_items,
        'total_amount': total_amount
    })


@login_required(login_url='login')
def my_orders(request):
    orders = Order.objects.filter(user=request.user).prefetch_related('items__product')
    return render(request, 'my_orders.html', {'orders': orders})

@login_required(login_url='login')
def order_detail(request, order_id):
    
    order = get_object_or_404(Order, id=order_id, user=request.user)
    order_items = order.items.all()   
    
    return render(request, 'order_detail.html', {'order': order, 'order_items': order_items})


@login_required(login_url='login')
def payment(request):
    # Retrieve the amount from the session
    amount = request.session.get('total_amount')
    
    #if request.method == 'POST':
    if amount:
                settings = { 'store_id': 'faruk678fb62431f5a', 'store_pass': 'faruk678fb62431f5a@ssl', 'issandbox': True }
                sslcz = SSLCOMMERZ(settings)
                post_body = {}
                post_body['total_amount'] = amount
                post_body['currency'] = "BDT"
                post_body['tran_id'] = "12345"
                post_body['success_url'] = request.build_absolute_uri(reverse('home')),
                post_body['fail_url'] = request.build_absolute_uri(reverse('home')),
                post_body['cancel_url'] = request.build_absolute_uri(reverse('home')),
                post_body['emi_option'] = 0
                post_body['cus_name'] = "test"
                post_body['cus_email'] = "test@test.com"
                post_body['cus_phone'] = "01700000000"
                post_body['cus_add1'] = "customer address"
                post_body['cus_city'] = "Dhaka"
                post_body['cus_country'] = "Bangladesh"
                post_body['shipping_method'] = "NO"
                post_body['multi_card_name'] = ""
                post_body['num_of_item'] = 1
                post_body['product_name'] = "Test"
                post_body['product_category'] = "Test Category"
                post_body['product_profile'] = "general"


                response = sslcz.createSession(post_body) # API response
                gateway_url = response.get('GatewayPageURL')
                return HttpResponseRedirect(gateway_url)
